<?php 
    session_start(); 

    $txtEmail = $_POST['txtEmail'];
    $txtNickname = $_POST['txtNickname'];
    $txtSenha = $_POST['txtSenha'];

    include_once "BD.php";
    
    if (isset($_POST['txtEmail']) && isset($_POST['txtNickname']) && isset($_POST['txtSenha']) && !empty($_POST['txtEmail']) && !empty($_POST['txtSenha']) && !empty($_POST['txtNickname'])) {
        
        $sql = "SELECT * FROM usuario WHERE Email = '$txtEmail' AND senha = ' $txtSenha' AND Nickname = '$txtNickname';";

        $res = mysqli_query($conn, $sql);
        
        if (mysqli_query($conn, $sql)) {
            //mysqli_close($conn);
            
            //com >= 0 não estava funcionando;
            if (mysqli_num_rows($res) > 0) {
                    if ($row = mysqli_fetch_assoc($res)) {
                    ?> 
                    
                    <script>alert("Usuário já cadastrado!")</script>
                    
                    <?php
                        
                    }
                }else{
                    
                    //verificar se inseriu
                    $sql = "INSERT INTO usuario(Nickname, Senha, Email) VALUES('$txtNickname', '$txtSenha', '$txtEmail')";
                   
                    if (mysqli_query($conn, $sql)) {
                        
                        $_SESSION['usuarioID'] = $row['id'];
                        $_SESSION['usuario'] = $row['Nickname'];
                        
                        header("Location: index.php");   
                        
                    } else {
                        echo "Erro: " . $sql . "<br>" . mysqli_error($conn);
                    }

                }
                mysqli_close($conn);
            //header("Location: index.php");   
        }else{
            echo "Erro: " . $sql . "<br>" . mysqli_error($conn);
        }
        
        $usernameLogin=$_POST['txtEmail'];
        $passwordLogin=$_POST['txtSenha'];

        $sql = "SELECT * FROM usuario WHERE email = '$usernameLogin' AND senha = '$passwordLogin';";
        $res = mysqli_query($conn, $sql);
        $_SESSION['usuarioID'] = $row['id'];
        $_SESSION['usuario'] = $row['Nickname'];
        

        
       
    }else{
        
        ?> 
            
            <script>alert("Preencha os dados para jogar!")</script>
            
        <?php
        
        //header("Location: index.php");
        
    }

?>