 <h3 style="text-align:center; font-size:1.2vw">RANKINGS DAS JOGADAS</h3>     

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<div class="accordion" id="accordionExample">
  <div class="">
    <div class="" id="headingOne">
      <h5 class="mb-0">
        <button type="button" class="btn" value="DIFICULDADE FÁCIL" data-toggle="collapse" data-target="#collapseFacil" aria-expanded="false" aria-controls="collapseFacil" style="width: 100%; border-radius: 50px; background-color: #00CDF4; color: white; font-weight: bold; font-size: 1vw; hover: button"> DIFICULDADE FÁCIL <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down-fill" viewBox="0 0 16 16">
                <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/>
        </svg></button>	
      </h5>
    </div>
    <br>
    <div id="collapseFacil" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="" style="overflow-y: scroll; max-height: 300px;">
        <table class="tabela ">
			<tr>
				<th>#</th>
				<th>Nickname</th>
				<th>Id</th>
				<th>Time</th>
				<th>Rounds</th>
			</tr>

			<?php

			    include "BD.php";
    
    			$valDificuldade = "facil";
    			$lista = array();
    
    			$sql = "SELECT * FROM jogada WHERE dificuldade='$valDificuldade' ORDER BY rodada ASC;";
    
    			$res = $conn->query($sql);
    			$row = $res->fetch_assoc();
    			
    			if(mysqli_num_rows($res) > 0){
    			
        			$i = 1;
        			
        			$idJogada = $row['ID'];
        			$idUser =$row['idUsuario'];
        			$Tempo =$row['tempo'];
        			$Rodada =$row['rodada'];
        			
        			array_push($lista, $idUser);
        			
        			$sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
        			$res2 = $conn->query($sql2);
        			$row2 = $res2->fetch_assoc();
        			
        			$Usuario = $row2['Nickname'];
    			
    			?>

			<tr>
				<td> <?php echo $i. "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
    			
                
                while($row = $res->fetch_assoc()){
                    
                
			        $idJogada = $row['ID'];
			        
        			$idUser = $row['idUsuario'];
        			$Tempo = $row['tempo'];
        			$Rodada = $row['rodada'];
        			$i = $i + 1;
        			
        			if(!in_array($idUser, $lista)){
        			    
        			    array_push($lista, $idUser);
        			
    			        $sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
            			$res2 = $conn->query($sql2);
            			$row2 = $res2->fetch_assoc();
        			
            			$Usuario = $row2['Nickname'];
		    ?>

			<tr>
			    
				<td> <?php echo $i . "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
			    
            			}else{
            			    $i = $i -1;
                        }
                    }    
    			}else{
    			    echo "<tr><td colspan='5'>Não há jogadas...</td></tr>";
    			}
    			
			
			?>

		</table>
      </div>
    </div>
  </div>
  <br>
  <div class="">
    <div class="" id="headingTwo">
      <h5 class="mb-0">
      <button type="button" class="btn" value="DIFICULDADE MÉDIA" data-toggle="collapse" data-target="#collapseMedia" aria-expanded="false" aria-controls="collapseMedia" style="width: 100%; border-radius: 50px; background-color: #00CDF4; color: white; font-weight: bold; font-size: 1vw; hover: button"> DIFICULDADE MÉDIA <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down-fill" viewBox="0 0 16 16">
  <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/>
</svg></button>
      </h5>
    </div>
    <br>
    <div id="collapseMedia" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class=""  style="overflow-y: scroll; max-height: 300px;">
       <table class="tabela">
			<tr>
				<th>#</th>
				<th>Nickname</th>
				<th>Id</th>
				<th>Time</th>
				<th>Rounds</th>
			</tr>
			
				<?php

			    include "BD.php";
    
    			$valDificuldade = "medio";
    			$lista = array();
    
    			$sql = "SELECT * FROM jogada WHERE dificuldade='$valDificuldade' ORDER BY rodada ASC;";
    
    			$res = $conn->query($sql);
    			$row = $res->fetch_assoc();
    			
    			if(mysqli_num_rows($res) > 0){
    			
        			$i = 1;
        			
        			$idJogada = $row['ID'];
        			$idUser =$row['idUsuario'];
        			$Tempo =$row['tempo'];
        			$Rodada =$row['rodada'];
        			
        			array_push($lista, $idUser);
        			
        			$sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
        			$res2 = $conn->query($sql2);
        			$row2 = $res2->fetch_assoc();
        			
        			$Usuario = $row2['Nickname'];
    			
    			?>

			<tr>
				<td> <?php echo $i. "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
    			
                
                while($row = $res->fetch_assoc()){
                    
                
			        $idJogada = $row['ID'];
			        
        			$idUser = $row['idUsuario'];
        			$Tempo = $row['tempo'];
        			$Rodada = $row['rodada'];
        			$i = $i + 1;
        			
        			if(!in_array($idUser, $lista)){
        			    
        			    array_push($lista, $idUser);
        			
    			        $sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
            			$res2 = $conn->query($sql2);
            			$row2 = $res2->fetch_assoc();
        			
            			$Usuario = $row2['Nickname'];
		    ?>

			<tr>
			    
				<td> <?php echo $i . "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
			    
            			}else{
            			    $i = $i -1;
                        }
                    }    
    			}else{
    			    echo "<tr><td colspan='5'>Não há jogadas...</td></tr>";
    			}
    			
			
			?>

		</table>
      </div>
    </div>
  </div>
  <br>
  <div class="">
    <div class="" id="headingThree">
      <h5 class="mb-0">
      <button type="button" class="btn" value="DIFICULDADE DIFÍCIL" data-toggle="collapse" data-target="#collapseDificil" aria-expanded="false" aria-controls="collapseDificil" style="width: 100%; border-radius: 50px; background-color: #00CDF4; color: white; font-weight: bold; font-size: 1vw; hover: button"> DIFICULDADE DIFÍCIL <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down-fill" viewBox="0 0 16 16">
  <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/>
</svg></button>	
      </h5>
    </div>
    <br>
    <div id="collapseDificil" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
    <div class="" style="overflow-y: scroll; max-height: 300px;">
        <table class="tabela ">
			<tr>
				<th>#</th>
				<th>Nickname</th>
				<th>Id</th>
				<th>Time</th>
				<th>Rounds</th>
			</tr>
			
				<?php

			    include "BD.php";
    
    			$valDificuldade = "dificil";
    			$lista = array();
    
    			$sql = "SELECT * FROM jogada WHERE dificuldade='$valDificuldade' ORDER BY rodada ASC;";
    
    			$res = $conn->query($sql);
    			$row = $res->fetch_assoc();
    			
    			if(mysqli_num_rows($res) > 0){
    			
        			$i = 1;
        			
        			$idJogada = $row['ID'];
        			$idUser =$row['idUsuario'];
        			$Tempo =$row['tempo'];
        			$Rodada =$row['rodada'];
        			
        			array_push($lista, $idUser);
        			
        			$sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
        			$res2 = $conn->query($sql2);
        			$row2 = $res2->fetch_assoc();
        			
        			$Usuario = $row2['Nickname'];
    			
    			?>

			<tr>
				<td> <?php echo $i. "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
    			
                
                while($row = $res->fetch_assoc()){
                    
                
			        $idJogada = $row['ID'];
			        
        			$idUser = $row['idUsuario'];
        			$Tempo = $row['tempo'];
        			$Rodada = $row['rodada'];
        			$i = $i + 1;
        			
        			if(!in_array($idUser, $lista)){
        			    
        			    array_push($lista, $idUser);
        			
    			        $sql2 = "SELECT Nickname FROM usuario WHERE ID = $idUser;";
        
            			$res2 = $conn->query($sql2);
            			$row2 = $res2->fetch_assoc();
        			
            			$Usuario = $row2['Nickname'];
		    ?>

			<tr>
			    
				<td> <?php echo $i . "°"; ?> </td>
				<td> <?php echo $Usuario; ?> </td>
				<td> <?php echo $idUser; ?> </td>
				<td> <?php echo $Tempo; ?> </td>
				<td> <?php echo $Rodada; ?> </td>

			</tr>
			
			<?php
			    
            			}else{
            			    $i = $i -1;
                        }
                    }    
    			}else{
    			    echo "<tr><td colspan='5'>Não há jogadas...</td></tr>";
    			}
    			
			
			?> 
		</table>
      </div>
    </div>
  </div>
</div>