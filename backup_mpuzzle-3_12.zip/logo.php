<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rampart+One&display=swap" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Rampart+One&display=swap');
</style>
<style type="text/css">
.logo:hover {
	cursor: pointer;
    -webkit-transform: translateY(-30px);
    -moz-transform: translateY(-30px);
    -ms-transform: translateY(-30px);
    -o-transform: translateY(-30px);
    transform: translateY(-30px);
}
	 
.logo{
    color: #FFD670;
   
    font-family: 'Rampart One', cursive;

    font-size: 5vw;  
    text-align: center;
    font-style: normal;
    font-weight: bold;

	cursor: pointer;
	position: relative;
    -webkit-transform: translateY(0);
    -moz-transform: translateY(0);
    -ms-transform: translateY(0);
    -o-transform: translateY(0);
    transform: translateY(0);
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    -moz-transition: 0.5s;
    transition: 0.5s;
}

table, td{
    border-collapse: collapse;
}
 
</style>


    <table class="table table-borderless">
    
    <td><h1 class="logo">m</h1></td>
    <td><h1 class="logo">p</h1></td>
    <td><h1 class="logo">u</h1></td>
    <td><h1 class="logo">z</h1></td>
    <td><h1 class="logo">z</h1></td>
    <td><h1 class="logo">l</h1></td>
    <td><h1 class="logo">e</h1></td>
    
    </table>

