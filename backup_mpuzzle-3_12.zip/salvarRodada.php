<?php   

    session_start();
    
    $Id = $_SESSION['usuarioID'];
    $User = $_SESSION['usuario'];
    $tempo = $_GET['time'];
    $rodadas = $_GET['rounds'];
    $dificuldade = $_GET['dificuldade'];

    include_once "BD.php";

    $sql = "INSERT INTO jogada(dificuldade, idUsuario, tempo, rodada) VALUES('$dificuldade', $Id, '$tempo', $rodadas)";

    if (mysqli_query($conn, $sql)) {
    	mysqli_close($conn);

    	header("Location: mpuzzle.php");	
    }else{
    	echo "Erro: " . $sql . "<br>" . mysqli_error($conn);
        mysqli_close($conn);
    }

?>