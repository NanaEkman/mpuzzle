<?php
    session_start();  

    include_once "BD.php";

    if (isset($_POST['txtEmail']) && isset($_POST['txtSenha']) && !empty($_POST['txtEmail']) && !empty($_POST['txtSenha'])) {
        $usernameLogin=$_POST['txtEmail'];
        $passwordLogin=$_POST['txtSenha'];

        $sql = "SELECT * FROM usuario WHERE email = '$usernameLogin' AND senha = '$passwordLogin';";

        $res = mysqli_query($conn, $sql);
 
        if (mysqli_num_rows($res) > 0) {
            if ($row = mysqli_fetch_assoc($res)) {
                $_SESSION['usuario'] = $row['Nickname']; 
                $_SESSION['usuarioID'] = "a" + $row['ID'];
                header("Location: mpuzzle.php");
            }
        }else{
            

            header("Location: index.php");
            

        }
        mysqli_close($conn);
       
    }else{

            header("Location: index.php");

        
    }
    

    
    
?> 