<style>
    
    .dif:focus{
		background-color: white;
	}
</style>
<div id="dificuldades" class="dificuldades collapse show">
<div class="btn-group btn-group-toggle" data-toggle="buttons">
    
    <label class="dif btn active" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #15ea6b; font-size: 1.2vw;">
    <input type="radio" name="dificuldade" value="facil" data-container="body" data-toggle="popover" data-placement="top" data-content="Básico." autocomplete="off" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #15ea6b;  font-size: 1vw;" placeholder="Fácil 4x4" checked><strong>Fácil 4x4</strong>  
  </label>

  <label class="dif btn" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #ff874a;  font-size: 1.2vw;">
    <input type="radio" name="dificuldade" value="medio" data-container="body" data-toggle="popover" data-placement="top" data-content="Um pouco mais difícil..." autocomplete="off" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #ff874a;  font-size: 1vw;" placeholder="Médio 6x6"><strong>Médio 6x6</strong> 
  </label>

  <label class="dif btn" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #ee3e61;  font-size: 1.2vw;">
    <input type="radio" name="dificuldade" value="dificil" data-container="body" data-toggle="popover" data-placement="top" data-content="Impossível!!!" autocomplete="off" style="color:white; background-color: #3d34c25d; border-color: #3d34c25d; color: #ee3e61;  font-size: 1vw;" placeholder="Difícil 8x8"><strong>Difícil 8x8</strong> 
  </label>
  
</div>
<br>
</div>

<div class="time collapse" id="time">
    <span id="tempo">Tempo:</span>
    <span class="minutos">00</span>
    <span>:</span>
    <span class="segundos">00</span>
    <span>:</span>
    <span class="milissegundos">00</span>
</div>
	
<div class="rounds collapse" id="rounds">
    <span id="rodadas">Rodadas:</span>
    <span class="rodada" id="rodada">0</span>
</div>
<br>
<div class="botoes">
    <button onclick="pausarRetomar()" class="pausarRetomar collapse" id="pausarRetomar" value="PAUSAR" disable=true>PAUSAR</button>
    <button onclick="jogarParar()" class="jogarParar" id="jogarParar" value="JOGAR">JOGAR</button>
</div> 