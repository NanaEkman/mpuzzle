<?php 

    session_start();
    
    $Id = $_SESSION['usuarioID'];
    $txtEmail = $_POST['txtEmail'];
    $txtNickname = $_POST['txtNickname'];
    $txtSenha = $_POST['txtSenha'];
    

    include_once "BD.php";

    $sql = "UPDATE usuario SET Nickname='$txtNickname', senha='$txtSenha', Email='$txtEmail' WHERE ID=$Id;";
    
    if (mysqli_query($conn, $sql)) {
    	mysqli_close($conn);
        $_SESSION['usuario'] = $txtNickname;
    	header("Location: mpuzzle.php");	
    }else{
    	echo "Erro: " . $sql . "<br>" . mysqli_error($conn);
        mysqli_close($conn);
    }

?>