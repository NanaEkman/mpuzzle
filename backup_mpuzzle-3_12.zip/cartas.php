<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<title>mpuzzle</title>
<style>
.front-face{
    background-color: #3d28c4;
    border-radius: 5px;
    display: block;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    
}

.back-face {
    background-color: #3d28c4;
    border-radius: 5px;
    position: absolute;
    top: 0;
    display: block;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    
}

.acertada {
    background-color: black;
    border-radius: 5px;
    position: absolute;
    top: 0;
    display: block;
    background-size: cover;
    background-position: center;
    opacity:0.4
}

.back-face:hover, 
.back-face:focus{
 transform:translateX(1px) scale(1.05);
}

/*.back-face:active{*/
/*  transition: all .2s ease-in-out;*/
/*  transform: scale(0.7);*/

/*}*/

.facil{
	width: 7.75vw; 
  	height: 7.75vw;
  	margin-bottom:1vw;
}

.medio{
	width: 5.1667vw;
  	height: 5.1667vw;
  	margin-bottom:0.5vw;
}

.dificil{
	width: 3.875vw;
  	height: 3.875vw;
  	margin-bottom:0.5vw;
}
</style>
</head>
<body>

<main>

    <section class="row justify-content-md-center align-items-center">


    </section>

</main>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<link rel="shortcut icon" href="#">
<script>
document.getElementById("pausarRetomar").disabled = true;
//4x4 - 150px
//6x6 - 100px
//8x8 - 50px

//<!-- ########################### cronometro ########################### -->
//<!-- Fonte referência: https://brasil.hackclub.com/workshops/cronometro/ -->	

	//pegando os numeros do cronometro
	const miliseg = document.querySelector('.milissegundos')
	const seg = document.querySelector('.segundos')
	const min = document.querySelector('.minutos')
	
	let miliNum = 0
	let segNum = 0
	let minNum = 0
	let INTERVALO
	
	//função pra contar os milissegundos
	function milissegundos() {
		  miliNum++
		  if (miliNum < 10) {
		    miliseg.innerHTML = '0' + miliNum
		  } else {
		    miliseg.innerHTML = miliNum
		  }
		  if (miliNum == 99) {
		    miliNum = 0
		    segundos() 
		  }
		}
	//função para contar os segundos
	function segundos() {
		segNum++
		if (segNum < 10) {
		  	seg.innerHTML = '0' + segNum
		} else {
		  	seg.innerHTML = segNum
		}
		
		if (segNum == 59) {
		  	segNum = 0
		  	minutos()
		}
	}
	//função para contar os minutos
	function minutos() {
		minNum++
		if (minNum < 10) {
		  	min.innerHTML = '0' + minNum
		} else {
		  	min.innerHTML = minNum
		}
	}
	
    //<!-- ########################### iniciar jogo ########################### -->
	//função para iniciar e parar o jogo e o cronometro!!!!!!!!!!!!!!!!!!!!!!!

	var numlado;
	var numCartas;
	var numImagens;
	var dificuldade;
	function jogarParar(){
		
		var valueBotao = document.getElementById("jogarParar").value

        //<!-- ########################### dificuldade ########################### -->
        dificuldade = document.querySelector('input[name=dificuldade]:checked').value
            
        if(dificuldade == "facil"){
            numLado = 4;
        }else if(dificuldade == "medio"){
            numLado = 6;
        }else if(dificuldade == "dificil"){
            numLado = 8;
        }

        numCartas = numLado*numLado;
		numImagens = numCartas/2
		
		if (valueBotao == "JOGAR"){
			
			comecarCriarCartas() //gera cartas
			aparecerMenu()
			limpar()//limpa os numeros da rodada anterior
			iniciar() //inicia cronometro
            document.getElementById("pausarRetomar").disabled = false;
			document.getElementById("jogarParar").value = "PARAR"
			document.getElementById("jogarParar").textContent = "PARAR"
			document.getElementById("jogarParar").style.backgroundColor = "#ee3e61"
			
		} else if (valueBotao == "PARAR"){
			
			Swal.fire({
				title: 'ATENÇÃO!',
				text: "VOCÊ ESTÁ PARANDO O JOGO ANTES DE TERMINAR! TODOS OS DADOS SERÃO PERDIDOS. DESEJA MESMO DESISTIR?",
				icon: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'DESISTIR',
				cancelButtonText: 'CANCELAR'
				}).then((result) => {
				if (result.isConfirmed) {
					limpar() //para o cronometro
			
					deletarCartas()
					esconderMenu()

					document.getElementById("pausarRetomar").disabled = true;
					//e cancela o jogo restaurando as informações
					document.getElementById("jogarParar").value = "JOGAR"
					document.getElementById("jogarParar").textContent = "JOGAR"
					document.getElementById("jogarParar").style.backgroundColor = "#3bc472"
				}
				})
			
			
			
		}		
	}
	
	//função para pausar e retomar o jogo e o cronometro
	function pausarRetomar(){
			
		var valueBotao = document.getElementById("pausarRetomar").value
		
		if (valueBotao == "PAUSAR"){
			
			pausar() //pausa o cronometro
			document.getElementById("pausarRetomar").value = "RETOMAR"
			document.getElementById("pausarRetomar").textContent = "RETOMAR"
			
			desativarOnclick()
			
		} else if (valueBotao == "RETOMAR"){ 
			
			
			
			retomar() //retomar
			document.getElementById("pausarRetomar").value = "PAUSAR"
			document.getElementById("pausarRetomar").textContent = "PAUSAR"
			ativarOnclick()
			
		}
			
		
	}

	//função para iniciar o cronometro
	function iniciar() {
		clearInterval(INTERVALO)
		INTERVALO = setInterval(() => {
			milissegundos()
		}, 10)
	}
	
	//função para pausar o cronometro
	function pausar() {
		clearInterval(INTERVALO)
	}
	
	//função para retomar o jogo e o cronometro
	function retomar() {
		//IMPLEMENTAR
		iniciar()
		//reativa as cartas
	}
	
	//função para parar o cronometro e o jogo
	function limpar() {
        const miliseg = document.querySelector('.milissegundos')
	    const seg = document.querySelector('.segundos')
	    const min = document.querySelector('.minutos')
		clearInterval(INTERVALO)
		miliNum = 0
		segNum = 0
		minNum = 0
		miliseg.innerHTML = '00'
		seg.innerHTML = '00'
		min.innerHTML = '00'
		
		//pegando o numero da rodada
		const rodada = document.querySelector('.proxRodada')
		document.getElementById("rodada").textContent = 0
	}
	
//<!-- ########################### criação das cartas ########################### -->
	function comecarCriarCartas(){
		var ids = gerar_ids(numImagens)
		montar_cartas(ids)
		
	}
	//gera uma lista de ids duplicados
	function gerar_ids(quant) {
		var ids = [];
		for (let i = 1; i < quant+1; i++) {
			ids.push(i);
			ids.push(i);
		}
		embaralhar_ids(ids);
		return ids;
	}
	//embaralha a lista de ids duplicados
	function embaralhar_ids(ids) {
	    for (let i = ids.length - 1; i > 0; i--) {
		    const j = Math.floor(Math.random() * (i + 1));
		    [ids[i], ids[j]] = [ids[j], ids[i]];
		}
		return ids;
	}
	
	function montar_cartas(ids){
	
		$(document).ready(function(e){
			
			//lista com as imagens das cartas
			var imagens  = ["https://pbs.twimg.com/media/E6S_4Z7XoAEXQPa?format=jpg&name=small", "https://assets.afcdn.com/story/20170731/1110290_w378h270c1cx628cy628.webp", "https://s1.static.brasilescola.uol.com.br/be/conteudo/images/o-golfinho-um-exemplo-animal-pertencente-ao-grupo-dos-mamiferos-5bd334f3235f1.jpg", "https://pbs.twimg.com/media/EEDU44oXUAMAMo6.jpg", "http://www.portaldosanimais.com.br/wp-content/uploads/2019/11/Animais-Fofos-e-Engra%C3%A7ados-5.jpg", "https://guiaanimal.net/uploads/article/image/467/cougar-275945_1920.jpg", "https://escolaeducacao.com.br/wp-content/uploads/2020/01/animais-com-o-750x430.jpg", "https://pbs.twimg.com/media/EsimwBtXAAEXwF3.jpg", "http://4.bp.blogspot.com/-oOMUPs18HKk/UePy5CrMHwI/AAAAAAAABDs/-SEzvHg0U1A/s640/redpanda2.jpeg", "https://i.pinimg.com/236x/4a/30/cb/4a30cbe9065b00a680bd17a5e1b5ede0.jpg", "https://i.pinimg.com/originals/1b/8b/a7/1b8ba7b777f5f9e951dd2a5e556fd4a6.jpg", "https://www.gov.br/icmbio/pt-br/centrais-de-conteudo/verdevibora-jpeg", "https://gazetadasemana.com.br/images/noticias/72059/10052304_b6121d3d-8.jpg.jpg", "https://tribunadejundiai.com.br/wp-content/uploads/2022/06/Cachorrinho-adotado-por-empresa-e-responsavel-por-espalhar-alegria-e-tirar-umas-sonecas1.jpeg", "https://img.freepik.com/fotos-gratis/vista-frontal-do-conceito-de-cachorro-fofo-engracado_23-2148786532.jpg?size=626&ext=jpg", "https://i.pinimg.com/564x/54/af/f2/54aff2bf63fc8557cb8a9bc6f7f6e15a.jpg", "https://www.hypeness.com.br/1/2016/12/frog-photography-tantoYensen-20-5836fb8e09efa__880.jpg", "https://portaldoscaesegatos.com.br/wp-content/uploads/2016/07/fotos-engra%C3%A7adas-de-animais-1.jpg", "https://1.bp.blogspot.com/-4SpTHHaWt20/YEZp93duLHI/AAAAAAAAAek/FKqOHVHU5OEdkbT29SuD3cNo-w5PmC7YwCNcBGAsYHQ/s564/porquineo%2Bduck.jpg", "https://www.petz.com.br/blog/wp-content/uploads/2021/11/animal-mais-bonito-do-mundo2-1280x720.jpg", "https://i0.wp.com/top10mais.org/wp-content/uploads/2015/08/Shetland-Pony-entre-as-racas-de-cavalos-mais-caras-do-mundo.jpg?resize=600%2C359&ssl=1", "https://www.teclasap.com.br/wp-content/uploads/2011/04/ladybug1.jpg", "https://www3.unicentro.br/petfisica/wp-content/uploads/sites/54/2018/06/Fen%C3%B4meno-Morpho.jpg", "https://i.pinimg.com/originals/52/8b/b8/528bb84de733a2157f13e7974cfa5211.jpg", "https://meusanimais.com.br/wp-content/uploads/2018/10/curiosidades-sobre-o-bicho-preguica.jpg", "https://cinebuzz.uol.com.br/media/_versions/legacy/2019/04/17/lionel-1140997_widexl.jpg", "https://i.pinimg.com/236x/cb/f6/c8/cbf6c86e64c51f0667c44419e12a096b.jpg", "https://www.hypeness.com.br/1/2016/10/QizaiPanda_destaque.jpg", "https://miro.medium.com/max/988/1*t-6heR0FxhZHQtAst7XiMg.jpeg", "https://static.escolakids.uol.com.br/2022/05/raposa-artico.jpg", "https://www.ripleyaquariums.com/canada/files/2020/04/Jellyfish-Camera_No-Text1800x1200.jpg", "https://topbiologia.com/wp-content/uploads/2014/04/raia-lenga-1.jpg", "https://blog.cobasi.com.br/wp-content/uploads/2021/10/rabbit-gc617360e0_640.jpg", "https://super.abril.com.br/wp-content/uploads/2018/07/566b17ea82bee174ca02c804thinkstockphotos-167229936.jpeg", "https://pbs.twimg.com/profile_images/1217294616128606210/q11eEcQ0_400x400.jpg", "https://live.staticflickr.com/3055/4593802479_debf4fa285_b.jpg", "https://img.estadao.com.br/resources/jpg/8/6/1603832656468.jpg", "https://static.escolakids.uol.com.br/2019/07/lontra.jpg", "https://portaleducacao.hortolandia.sp.gov.br/media/k2/items/cache/2db5d9d6faf8ee640940b5e176223700_XL.jpg", "https://www.fatosdesconhecidos.com.br/wp-content/uploads/2022/03/axolote-1-474x604.jpg", "https://static.nationalgeographicbrasil.com/files/styles/image_3200/public/comedy-wildlife-awards-squirel-stop.jpg?w=1190&h=888", "https://static1.patasdacasa.com.br/articles/6/39/36/@/17168-fotos-de-cachorros-engracados-carisma-d-articles_media_slider_mobile-2.jpg"];
	    	
			var lista = embaralhar_ids(imagens);

			var cont = -1;
	
		    for (let i = 0; i < numCartas ; i++) {
		
				let id = ids[i];
		        let divCarta = $("<div>");
		        divCarta.addClass("col-auto "+ dificuldade);
		        
		        for(j = 0; j < lista.length; j++){
		        	if(id == j+1){
		        		let link = lista[j];
                        let divFront = $("<div>");
                        divFront.addClass("front-face "+ dificuldade)
						divFront.css("background-image", "url('"+link+"')")
                        divCarta.append(divFront)
		    	         
                        let divBack = $("<div>");
                        divBack.addClass("back-face "+ dificuldade)
						divBack.css("background-image", "url('https://cdn-icons-png.flaticon.com/512/5726/5726642.png')")
						divBack.attr('id', id)
                        divBack.attr("onclick", "clicou()")    
                        divCarta.append(divBack)

						cont++;
		        	}

					if (cont == numLado){
						cont = 0;
						let divQuebra = $("<div>");
		        		divQuebra.addClass("w-100");
						$("body main section").append(divQuebra);
					}
		        }
		        
		        $("body main section").append(divCarta);
		        
		    }
	
		})
	}

//<!-- ########################### aparecer menu  ########################### -->
function aparecerMenu(){
	document.getElementById("dificuldades").classList.remove("show");
	document.getElementById("time").classList.add("show")
	document.getElementById("rounds").classList.add("show")
	document.getElementById("pausarRetomar").classList.add("show")
}

//<!-- ########################### desaparecer menu  ########################### -->
function esconderMenu(){
	document.getElementById("dificuldades").classList.add("show");
	document.getElementById("time").classList.remove("show")
	document.getElementById("rounds").classList.remove("show")
	document.getElementById("pausarRetomar").classList.remove("show")
}

//<!-- ########################### esperar x segundos ########################### -->
// function sleep(milliseconds) {
//   const date = Date.now();
//   let currentDate = null;
//   do {
//     currentDate = Date.now();
//   } while (currentDate - date < milliseconds);
// }

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

//<!-- ########################### desativar onclick ########################### -->
function desativarOnclick(){
    const cartas = document.getElementsByClassName("back-face")
    for (carta of cartas){
        carta.setAttribute("onclick","")
    }
}

//<!-- ########################### ativar onclick ########################### -->
function ativarOnclick(){
    const cartas = document.getElementsByClassName("back-face")
    for (carta of cartas){
        carta.setAttribute("onclick","clicou()")
    }
}

//<!-- ########################### comparação das cartas ########################### -->
	var cartasSelecionadas = 0;
	var id1;
	var id2;
	var carta1;
	var carta2;
	var qtdAcertos = 0;

	function clicou(){
        var carta = event.target;
        carta.style.display = "none";
		
		cartasSelecionadas ++;
		
		if (cartasSelecionadas == 1) {
			carta1 = event.target;
		    id1 = carta1.id;
		    
			carta1.setAttribute("onclick","")
		}
		
		if (cartasSelecionadas == 2) {	
			carta2 = event.target;
		    id2 = carta2.id;
		    console.log(carta1)
			console.log(carta2)
			carta2.setAttribute("onclick","")

            //desativar onclick de todas
            desativarOnclick()

            sleep(800).then(() => {  
            //acertou
                if (id1 == id2) {
                    console.log("acertou")

                    carta1.style.display = "block";
                    carta2.style.display = "block";
                    carta1.style.backgroundImage = "";
                    carta2.style.backgroundImage = "";
                    carta1.classList.remove("back-face");
                    carta2.classList.remove("back-face");
                    carta1.classList.add("acertada")
                    carta2.classList.add("acertada")

                    ativarOnclick()

                    carta1.setAttribute("onclick","")
                    carta2.setAttribute("onclick","")
                    
                    
                    qtdAcertos += 1;

                } else {
                    //errou
                    console.log("errou")
                    
                    carta1.style.display = "block";
                    carta2.style.display = "block";
                    
                    ativarOnclick()

                }

                cartasSelecionadas = 0
                proxRodada()
				
				if (qtdAcertos == numImagens) {
					pausar()//para o cronometro
					sleep(500).then(() => {
						
						
						const rodada = document.querySelector('.proxRodada')
						var rounds = parseInt(document.getElementById("rodada").textContent)
						var dificuldade = document.querySelector('input[name=dificuldade]:checked').placeholder
						const miliseg = document.querySelector('.milissegundos').innerHTML
						const seg = document.querySelector('.segundos').innerHTML
						const min = document.querySelector('.minutos').innerHTML
						var time = min.toString() + ":" + seg.toString() + ":" +miliseg.toString()
						Swal.fire({
							title: 'PARABÉNS VOCÊ GANHOU!!',
							html: "DADOS DA SUA JOGADA:<br><br>"
								+"DIFICULDADE: "+dificuldade+" | RODADAS: "+rounds+" | TEMPO: "+time
								+"<br><br>CONFIRA SUA POSIÇÃO NO RANKING!",
							imageUrl: 'https://capricho.abril.com.br/wp-content/uploads/2017/03/cachorro-funk.gif',
							imageAlt: 'GIF de Parabéns!!',
							width: 700,
							showClass: {
								popup: 'animate__bounceIn animate__tada'
							},
							hideClass: {
								popup: 'animate__bounceOut'
							},
							showCancelButton: false,
							confirmButtonColor: '#3085d6',
							confirmButtonText: 'VAMOS LÁ!'

														
							}).then((result) => {
							if (result.isConfirmed) {
								deletarCartas()
								//e cancela o jogo restaurando as informações
								document.getElementById("jogarParar").value = "jogar"
								document.getElementById("jogarParar").textContent = "Jogar"

								qtdAcertos = 0;

								salvarRodada()
							} else {
								deletarCartas()
								//e cancela o jogo restaurando as informações
								document.getElementById("jogarParar").value = "jogar"
								document.getElementById("jogarParar").textContent = "Jogar"

								qtdAcertos = 0;

								salvarRodada()
							}
							})

					});
				}	
            });
		}
		
		
	}


	//<!-- ########################### rodadas ########################### -->
	//<!-- JavaScript incrementar o contador de rodadas -->
	//função para incrementar a rodada
	function proxRodada() {
		//pegando o numero da rodada
		const rodada = document.querySelector('.proxRodada')
		
		var rodNum = parseInt(document.getElementById("rodada").textContent)
		rodNum ++
		document.getElementById("rodada").textContent = rodNum
	}
	
	//<!-- ########################### deletar cartas ########################### -->
	function deletarCartas(){
		 
      	var base = document.querySelectorAll('section div');
      	for (let div of base) {
      		div.remove();
      	  }	
	}
	

    //<!-- ########################### salvar rodada ########################### -->
    function salvarRodada(){
        const rodada = document.querySelector('.proxRodada')
		var rounds = parseInt(document.getElementById("rodada").textContent)
        var dificuldade = document.querySelector('input[name=dificuldade]:checked').value
        const miliseg = document.querySelector('.milissegundos').innerHTML
        const seg = document.querySelector('.segundos').innerHTML
        const min = document.querySelector('.minutos').innerHTML
        var time = min.toString() + ":" + seg.toString() + ":" +miliseg.toString()

        console.log("time="+time+"&rounds="+rounds+"&dificuldade="+dificuldade)
        
        window.location.href = "salvarRodada.php?time="+time+"&rounds="+rounds+"&dificuldade="+dificuldade;
            
        
    }
</script>

</body>
</html>